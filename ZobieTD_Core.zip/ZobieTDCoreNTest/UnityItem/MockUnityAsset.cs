﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZobieTDCoreNTest.UnityItem
{
    internal class MockUnityAsset
    {
        public string name { get; }
        public MockUnityAsset(string name)
        {
            this.name = name;
        }

    }
}
