﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZobieTDCore.Contracts.Items.AssetBundle
{
    public interface IAssetReference
    {
        string Name { get; }
    }
}
